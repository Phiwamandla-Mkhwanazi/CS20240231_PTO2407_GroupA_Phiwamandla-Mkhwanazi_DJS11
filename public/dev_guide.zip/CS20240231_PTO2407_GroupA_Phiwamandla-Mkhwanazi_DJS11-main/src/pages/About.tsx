import AboutUs from '../components/AboutUs';

export default function About(){
    return(
        <AboutUs />
    );
}