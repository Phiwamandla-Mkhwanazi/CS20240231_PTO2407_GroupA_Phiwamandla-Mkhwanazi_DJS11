import Main from '../components/Main';

function Home() {
  return (
        <Main />    
  );
}

export default Home;