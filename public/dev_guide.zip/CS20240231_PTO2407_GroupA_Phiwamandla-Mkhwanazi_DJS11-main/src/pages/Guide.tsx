import Guide from '../components/Guide';

function Home() {
  return (
        <Guide />
  );
}

export default Home;